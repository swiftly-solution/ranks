function GetPluginAuthor()
    return "Swiftly Solution"
end

function GetPluginVersion()
    return "v1.0.4"
end

function GetPluginName()
    return "Swiftly Ranks"
end

function GetPluginWebsite()
    return "https://github.com/swiftly-solution/ranks"
end
